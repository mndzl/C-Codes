#include <string>
#include <vector>

using namespace std;

int analizar(vector<vector<int>> &muestras) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
