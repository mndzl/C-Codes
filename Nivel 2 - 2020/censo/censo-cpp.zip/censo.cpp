#include <string>
#include <vector>

using namespace std;

int decada(int fecha) {
    return -1; // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

bool esmayor(int edad) {
    return false; // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

string nombrecompleto(string nombre, string apellido) {
    return "EJEMPLO"; // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

int cantidadmayores(vector<int> &edades) {
    return -1; // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
