#include <string>
#include <vector>

using namespace std;

long long thor(vector<int> &a, vector<int> &f, vector<int> &p, int D) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
