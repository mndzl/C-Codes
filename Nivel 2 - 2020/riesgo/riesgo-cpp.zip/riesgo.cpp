#include <string>
#include <vector>

using namespace std;

vector<int> riesgo(vector<int> &x, vector<int> &y, int D, vector<int> &positivos) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
