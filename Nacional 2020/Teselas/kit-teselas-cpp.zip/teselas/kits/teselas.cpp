#include <string>
#include <vector>

using namespace std;

void intercambiar(int fila1, int columna1, int fila2, int columna2);

int teselas(vector<string> &mosaico) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
