#include <string>
#include <vector>

using namespace std;

vector<int> cromosoma(string cadena) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
